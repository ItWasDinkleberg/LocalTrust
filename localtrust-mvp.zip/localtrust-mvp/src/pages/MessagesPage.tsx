import React from 'react'
import { Card, CardContent } from '../components/ui/Card'

export default function MessagesPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Card>
        <CardContent className="p-8 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Messages</h1>
          <p className="text-sm text-gray-500 mt-4">This page will show real-time messaging between users and providers.</p>
        </CardContent>
      </Card>
    </div>
  )
}