import React from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useServiceCategories } from '../hooks/useServices'
import { useAppStore } from '../store/useAppStore'
import { Button } from '../components/ui/Button'
import { Card, CardContent } from '../components/ui/Card'
import { 
  Search, 
  Shield, 
  Users, 
  Star, 
  ArrowRight, 
  CheckCircle, 
  MapPin, 
  Clock, 
  Award,
  Calendar
} from 'lucide-react'

export default function HomePage() {
  const navigate = useNavigate()
  const { setSearchFilters } = useAppStore()
  const { data: categories, isLoading: categoriesLoading } = useServiceCategories()

  const handleCategoryClick = (categoryId: string) => {
    setSearchFilters({ categoryId })
    navigate('/search')
  }

  const handleLocationSearch = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setSearchFilters({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude
          })
          navigate('/search')
        },
        () => {
          // If location access denied, just go to search
          navigate('/search')
        }
      )
    } else {
      navigate('/search')
    }
  }

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-50 to-green-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Find Trusted Local
              <span className="text-blue-600"> Service Providers</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Connect with verified professionals in your area. 
              Transparent pricing, blockchain-verified reviews, and secure payments.
            </p>
            
            {/* Search CTA */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
              <Button 
                size="lg" 
                onClick={handleLocationSearch}
                className="flex items-center space-x-2"
              >
                <Search className="w-5 h-5" />
                <span>Find Services Near Me</span>
              </Button>
              <Link to="/become-provider">
                <Button variant="outline" size="lg">
                  Become a Provider
                </Button>
              </Link>
            </div>

            {/* Trust Indicators */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
              <div className="flex items-center justify-center space-x-2 text-gray-600">
                <Shield className="w-5 h-5 text-green-600" />
                <span>Verified Providers</span>
              </div>
              <div className="flex items-center justify-center space-x-2 text-gray-600">
                <Star className="w-5 h-5 text-yellow-500" />
                <span>Blockchain Reviews</span>
              </div>
              <div className="flex items-center justify-center space-x-2 text-gray-600">
                <Users className="w-5 h-5 text-blue-600" />
                <span>Local Community</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Service Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Popular Service Categories
            </h2>
            <p className="text-lg text-gray-600">
              Browse trusted professionals across all service categories
            </p>
          </div>

          {categoriesLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {[...Array(10)].map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 rounded-lg h-24"></div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
              {categories?.filter(cat => !cat.parent_category_id).slice(0, 10).map((category) => (
                <Card 
                  key={category.id} 
                  className="cursor-pointer hover:shadow-lg transition-shadow"
                  onClick={() => handleCategoryClick(category.id)}
                >
                  <CardContent className="p-6 text-center">
                    <div className="text-2xl mb-2">🏠</div>
                    <h3 className="font-semibold text-gray-900">{category.name}</h3>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          <div className="text-center mt-8">
            <Link to="/search">
              <Button variant="outline">
                View All Categories
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              How LocalTrust Works
            </h2>
            <p className="text-lg text-gray-600">
              Simple, secure, and transparent service booking
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Search className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">1. Search & Compare</h3>
              <p className="text-gray-600">
                Find verified service providers in your area. Compare prices, read verified reviews, and check credentials.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">2. Book & Pay Securely</h3>
              <p className="text-gray-600">
                Schedule your service with our calendar system. Pay securely with our integrated payment processing.
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-8 h-8 text-yellow-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">3. Get Service & Review</h3>
              <p className="text-gray-600">
                Receive quality service from verified professionals. Leave blockchain-verified reviews to help others.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">
                Why Choose LocalTrust?
              </h2>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-green-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Verified Professionals</h3>
                    <p className="text-gray-600">All providers undergo thorough background checks and verification.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-green-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Blockchain-Verified Reviews</h3>
                    <p className="text-gray-600">Authentic, tamper-proof reviews you can trust.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-green-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Secure Payments</h3>
                    <p className="text-gray-600">Safe, encrypted payment processing with refund protection.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <CheckCircle className="w-6 h-6 text-green-600 mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Real-time Communication</h3>
                    <p className="text-gray-600">Direct messaging with providers for clear communication.</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <Card className="p-6 text-center">
                <Award className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">1000+</div>
                <div className="text-gray-600">Verified Providers</div>
              </Card>
              <Card className="p-6 text-center">
                <Star className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">4.9</div>
                <div className="text-gray-600">Average Rating</div>
              </Card>
              <Card className="p-6 text-center">
                <MapPin className="w-8 h-8 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">50+</div>
                <div className="text-gray-600">Cities Covered</div>
              </Card>
              <Card className="p-6 text-center">
                <Clock className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">24/7</div>
                <div className="text-gray-600">Support</div>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">
            Ready to Find Your Perfect Service Provider?
          </h2>
          <p className="text-blue-100 text-lg mb-8">
            Join thousands of satisfied customers who trust LocalTrust for their service needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              size="lg" 
              variant="secondary"
              onClick={handleLocationSearch}
            >
              Get Started Now
            </Button>
            <Link to="/become-provider">
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
                Join as Provider
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}