import React, { useState, useEffect } from 'react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import { useSearchServices, useServiceCategories } from '../hooks/useServices'
import { useAppStore } from '../store/useAppStore'
import { Button } from '../components/ui/Button'
import { Input } from '../components/ui/Input'
import { Card, CardContent } from '../components/ui/Card'
import { 
  Search, 
  Filter, 
  MapPin, 
  Star, 
  Shield, 
  Leaf, 
  Accessibility,
  Clock,
  DollarSign,
  ChevronDown
} from 'lucide-react'
import { formatCurrency } from '../lib/utils'

export default function SearchPage() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const { searchFilters, setSearchFilters } = useAppStore()
  const [showFilters, setShowFilters] = useState(false)
  const [localFilters, setLocalFilters] = useState(searchFilters)
  
  const { data: searchResults, isLoading, error } = useSearchServices(searchFilters)
  const { data: categories } = useServiceCategories()

  // Update search filters from URL params on mount
  useEffect(() => {
    const params = Object.fromEntries(searchParams)
    if (Object.keys(params).length > 0) {
      setSearchFilters(params)
      setLocalFilters(prev => ({ ...prev, ...params }))
    }
  }, [searchParams, setSearchFilters])

  const handleSearch = () => {
    setSearchFilters(localFilters)
  }

  const handleFilterChange = (key: string, value: any) => {
    setLocalFilters(prev => ({ ...prev, [key]: value }))
  }

  const clearFilters = () => {
    const clearedFilters = {
      query: '',
      categoryId: null,
      latitude: searchFilters.latitude,
      longitude: searchFilters.longitude,
      radius: 25,
      minPrice: null,
      maxPrice: null,
      minRating: null,
      sortBy: 'relevance' as const
    }
    setLocalFilters(clearedFilters)
    setSearchFilters(clearedFilters)
  }

  const handleServiceClick = (serviceId: string) => {
    navigate(`/service/${serviceId}`)
  }

  return (
    <div className="bg-gray-50 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search Input */}
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search for services..."
                  value={localFilters.query}
                  onChange={(e) => handleFilterChange('query', e.target.value)}
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                />
              </div>
            </div>

            {/* Category Filter */}
            <div className="lg:w-64">
              <select
                value={localFilters.categoryId || ''}
                onChange={(e) => handleFilterChange('categoryId', e.target.value || null)}
                className="w-full py-3 px-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="">All Categories</option>
                {categories?.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Filter Toggle */}
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="lg:w-auto"
            >
              <Filter className="w-4 h-4 mr-2" />
              Filters
              <ChevronDown className={`w-4 h-4 ml-2 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </Button>

            <Button onClick={handleSearch}>
              Search
            </Button>
          </div>

          {/* Advanced Filters */}
          {showFilters && (
            <div className="mt-6 pt-6 border-t border-gray-200">
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {/* Price Range */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Min Price</label>
                  <input
                    type="number"
                    placeholder="$0"
                    value={localFilters.minPrice || ''}
                    onChange={(e) => handleFilterChange('minPrice', e.target.value ? parseFloat(e.target.value) : null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Max Price</label>
                  <input
                    type="number"
                    placeholder="$1000"
                    value={localFilters.maxPrice || ''}
                    onChange={(e) => handleFilterChange('maxPrice', e.target.value ? parseFloat(e.target.value) : null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                {/* Radius */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Radius (miles)</label>
                  <select
                    value={localFilters.radius}
                    onChange={(e) => handleFilterChange('radius', parseInt(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value={5}>5 miles</option>
                    <option value={10}>10 miles</option>
                    <option value={25}>25 miles</option>
                    <option value={50}>50 miles</option>
                    <option value={100}>100 miles</option>
                  </select>
                </div>

                {/* Rating */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Min Rating</label>
                  <select
                    value={localFilters.minRating || ''}
                    onChange={(e) => handleFilterChange('minRating', e.target.value ? parseFloat(e.target.value) : null)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Any Rating</option>
                    <option value={3}>3+ Stars</option>
                    <option value={4}>4+ Stars</option>
                    <option value={4.5}>4.5+ Stars</option>
                  </select>
                </div>

                {/* Sort By */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Sort By</label>
                  <select
                    value={localFilters.sortBy}
                    onChange={(e) => handleFilterChange('sortBy', e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="relevance">Relevance</option>
                    <option value="rating">Highest Rated</option>
                    <option value="price_low">Price: Low to High</option>
                    <option value="price_high">Price: High to Low</option>
                    <option value="distance">Distance</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-between items-center mt-4">
                <Button variant="ghost" onClick={clearFilters}>
                  Clear All Filters
                </Button>
                <Button onClick={handleSearch}>
                  Apply Filters
                </Button>
              </div>
            </div>
          )}
        </div>

        {/* Results */}
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Results List */}
          <div className="flex-1">
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-white rounded-lg p-6">
                      <div className="h-4 bg-gray-200 rounded mb-4"></div>
                      <div className="h-3 bg-gray-200 rounded mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : error ? (
              <div className="text-center py-12">
                <p className="text-red-600">Error loading search results. Please try again.</p>
              </div>
            ) : !searchResults?.services?.length ? (
              <div className="text-center py-12">
                <Search className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">No services found</h3>
                <p className="text-gray-600 mb-4">Try adjusting your search criteria or location.</p>
                <Button onClick={clearFilters}>Clear Filters</Button>
              </div>
            ) : (
              <>
                <div className="mb-4 text-sm text-gray-600">
                  Found {searchResults.services.length} services
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {searchResults.services.map((service: any) => (
                    <Card 
                      key={service.id} 
                      className="cursor-pointer hover:shadow-lg transition-shadow"
                      onClick={() => handleServiceClick(service.id)}
                    >
                      <CardContent className="p-6">
                        {/* Service Image Placeholder */}
                        <div className="w-full h-48 bg-gray-200 rounded-lg mb-4 flex items-center justify-center">
                          <div className="text-gray-400 text-4xl">🛠️</div>
                        </div>

                        {/* Service Info */}
                        <div className="space-y-3">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-1">
                              {service.title}
                            </h3>
                            <p className="text-gray-600 text-sm line-clamp-2">
                              {service.description}
                            </p>
                          </div>

                          {/* Provider Info */}
                          <div className="flex items-center space-x-2 text-sm text-gray-600">
                            <span>{service.providers?.business_name}</span>
                            {service.providers?.verification_status === 'verified' && (
                              <Shield className="w-4 h-4 text-green-600" />
                            )}
                          </div>

                          {/* Rating */}
                          {service.providers?.rating_average > 0 && (
                            <div className="flex items-center space-x-1">
                              <Star className="w-4 h-4 text-yellow-400 fill-current" />
                              <span className="text-sm font-medium">
                                {service.providers.rating_average.toFixed(1)}
                              </span>
                              <span className="text-sm text-gray-500">
                                ({service.providers.review_count} reviews)
                              </span>
                            </div>
                          )}

                          {/* Price */}
                          <div className="flex items-center space-x-2">
                            <DollarSign className="w-4 h-4 text-gray-400" />
                            <span className="font-semibold text-gray-900">
                              {formatCurrency(service.base_price)}
                              {service.price_type === 'hourly' && '/hour'}
                            </span>
                          </div>

                          {/* Badges */}
                          <div className="flex flex-wrap gap-2">
                            {service.providers?.eco_friendly && (
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                                <Leaf className="w-3 h-3 mr-1" />
                                Eco-Friendly
                              </span>
                            )}
                            {service.providers?.accessibility_focused && (
                              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
                                <Accessibility className="w-3 h-3 mr-1" />
                                Accessible
                              </span>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Map Sidebar - Placeholder */}
          <div className="lg:w-96">
            <Card className="sticky top-6">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Service Locations</h3>
                <div className="w-full h-64 bg-gray-200 rounded-lg flex items-center justify-center">
                  <div className="text-center text-gray-500">
                    <MapPin className="w-8 h-8 mx-auto mb-2" />
                    <p className="text-sm">Map view coming soon</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}