import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://wreexelbdnlqnelluvow.supabase.co'
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndyZWV4ZWxiZG5scW5lbGx1dm93Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQzNzc4NjUsImV4cCI6MjA2OTk1Mzg2NX0.NmrM7WgVkCe2MTK3OKDaZQRigmJ8OiDtuKb2KuFF4Kw'

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true
  }
})

// Database types
export interface Profile {
  id: string
  full_name: string
  email: string
  phone?: string
  avatar_url?: string
  user_role: 'seeker' | 'provider' | 'admin'
  location_address?: string
  location_city?: string
  location_state?: string
  location_country?: string
  latitude?: number
  longitude?: number
  timezone?: string
  preferences: Record<string, any>
  email_notifications: boolean
  sms_notifications: boolean
  created_at: string
  updated_at: string
}

export interface ServiceCategory {
  id: string
  name: string
  description?: string
  icon_name?: string
  parent_category_id?: string
  is_active: boolean
  sort_order: number
  created_at: string
}

export interface Provider {
  id: string
  user_id: string
  business_name: string
  business_description?: string
  business_type: 'individual' | 'small_business' | 'company'
  business_phone?: string
  business_email?: string
  business_address?: string
  business_city?: string
  business_state?: string
  business_country?: string
  business_latitude?: number
  business_longitude?: number
  verification_status: 'pending' | 'verified' | 'rejected' | 'suspended'
  verification_documents: any[]
  service_radius: number
  years_experience?: number
  license_number?: string
  insurance_info?: Record<string, any>
  eco_friendly: boolean
  accessibility_focused: boolean
  commission_rate: number
  rating_average: number
  review_count: number
  total_bookings: number
  verified_at?: string
  created_at: string
  updated_at: string
}

export interface Service {
  id: string
  provider_id: string
  category_id: string
  title: string
  description: string
  price_type: 'fixed' | 'hourly' | 'custom'
  base_price: number
  hourly_rate?: number
  price_details?: Record<string, any>
  duration_minutes?: number
  location_type: 'customer' | 'provider' | 'both'
  service_area_radius: number
  requirements?: string
  what_included?: string
  gallery_images: string[]
  is_active: boolean
  booking_advance_days: number
  booking_lead_time_hours: number
  cancellation_policy?: string
  created_at: string
  updated_at: string
}

export interface Booking {
  id: string
  customer_id: string
  provider_id: string
  service_id: string
  booking_date: string
  start_time: string
  end_time?: string
  duration_minutes?: number
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled' | 'no_show'
  total_amount: number
  commission_amount?: number
  customer_notes?: string
  provider_notes?: string
  service_address?: string
  service_latitude?: number
  service_longitude?: number
  payment_status: 'pending' | 'paid' | 'refunded' | 'failed'
  stripe_payment_intent_id?: string
  confirmation_code?: string
  cancellation_reason?: string
  cancelled_by?: string
  cancelled_at?: string
  confirmed_at?: string
  completed_at?: string
  created_at: string
  updated_at: string
}

export interface Review {
  id: string
  booking_id: string
  reviewer_id: string
  reviewed_id: string
  rating: number
  title?: string
  comment?: string
  response?: string
  response_date?: string
  verification_hash?: string
  blockchain_verified: boolean
  is_featured: boolean
  helpful_count: number
  reported_count: number
  is_hidden: boolean
  created_at: string
  updated_at: string
}

export interface Message {
  id: string
  conversation_id: string
  sender_id: string
  receiver_id: string
  booking_id?: string
  message_type: 'text' | 'image' | 'file' | 'system'
  content: string
  attachments: any[]
  is_read: boolean
  read_at?: string
  is_system_message: boolean
  created_at: string
}

export interface Conversation {
  id: string
  customer_id: string
  provider_id: string
  booking_id?: string
  last_message_id?: string
  last_message_at?: string
  customer_unread_count: number
  provider_unread_count: number
  is_archived: boolean
  created_at: string
  updated_at: string
}