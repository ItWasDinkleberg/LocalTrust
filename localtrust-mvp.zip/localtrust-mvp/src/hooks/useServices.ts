import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase } from '../lib/supabase'
import { toast } from 'react-toastify'
import { useAppStore } from '../store/useAppStore'

interface SearchServicesParams {
  query?: string
  categoryId?: string | null
  latitude?: number | null
  longitude?: number | null
  radius?: number
  minPrice?: number | null
  maxPrice?: number | null
  minRating?: number | null
  sortBy?: string
  limit?: number
  offset?: number
}

export function useSearchServices(params: SearchServicesParams) {
  return useQuery({
    queryKey: ['search-services', params],
    queryFn: async () => {
      const { data, error } = await supabase.functions.invoke('search-services', {
        body: params
      })

      if (error) {
        throw error
      }

      return data.data
    },
    enabled: true,
    staleTime: 5 * 60 * 1000, // 5 minutes
  })
}

export function useServiceCategories() {
  return useQuery({
    queryKey: ['service-categories'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('service_categories')
        .select('*')
        .eq('is_active', true)
        .order('sort_order')

      if (error) {
        throw error
      }

      return data
    },
    staleTime: 30 * 60 * 1000, // 30 minutes
  })
}

export function useService(serviceId: string) {
  return useQuery({
    queryKey: ['service', serviceId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('services')
        .select(`
          *,
          providers!inner(
            business_name,
            rating_average,
            review_count,
            verification_status,
            eco_friendly,
            accessibility_focused,
            business_address,
            business_city,
            business_state,
            business_phone,
            business_email
          ),
          service_categories!inner(
            name,
            icon_name
          )
        `)
        .eq('id', serviceId)
        .eq('is_active', true)
        .maybeSingle()

      if (error) {
        throw error
      }

      return data
    },
    enabled: !!serviceId
  })
}

export function useServiceReviews(serviceId: string) {
  return useQuery({
    queryKey: ['service-reviews', serviceId],
    queryFn: async () => {
      // First get the provider ID from the service
      const { data: service, error: serviceError } = await supabase
        .from('services')
        .select('provider_id')
        .eq('id', serviceId)
        .maybeSingle()

      if (serviceError || !service) {
        throw serviceError || new Error('Service not found')
      }

      // Then get reviews for the provider
      const { data, error } = await supabase
        .from('reviews')
        .select(`
          *,
          profiles!reviews_reviewer_id_fkey(
            full_name,
            avatar_url
          )
        `)
        .eq('reviewed_id', service.provider_id)
        .eq('is_hidden', false)
        .order('created_at', { ascending: false })
        .limit(20)

      if (error) {
        throw error
      }

      return data
    },
    enabled: !!serviceId
  })
}