import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { supabase } from '../lib/supabase'
import { useAuth } from '../contexts/AuthContext'
import { toast } from 'react-toastify'

interface CreateBookingData {
  service_id: string
  provider_id: string
  booking_date: string
  start_time: string
  duration_minutes: number
  total_amount: number
  customer_notes?: string
  service_address?: string
  service_latitude?: number
  service_longitude?: number
}

export function useUserBookings() {
  const { user } = useAuth()
  
  return useQuery({
    queryKey: ['user-bookings', user?.id],
    queryFn: async () => {
      if (!user) throw new Error('User not authenticated')
      
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          services!inner(
            title,
            description,
            gallery_images
          ),
          providers!inner(
            business_name,
            business_phone,
            business_email
          )
        `)
        .eq('customer_id', user.id)
        .order('created_at', { ascending: false })

      if (error) {
        throw error
      }

      return data
    },
    enabled: !!user
  })
}

export function useProviderBookings() {
  const { user } = useAuth()
  
  return useQuery({
    queryKey: ['provider-bookings', user?.id],
    queryFn: async () => {
      if (!user) throw new Error('User not authenticated')
      
      // First get the provider ID
      const { data: provider, error: providerError } = await supabase
        .from('providers')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle()

      if (providerError || !provider) {
        return []
      }

      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          services!inner(
            title,
            description
          ),
          profiles!bookings_customer_id_fkey(
            full_name,
            phone,
            email
          )
        `)
        .eq('provider_id', provider.id)
        .order('created_at', { ascending: false })

      if (error) {
        throw error
      }

      return data
    },
    enabled: !!user
  })
}

export function useCreateBooking() {
  const queryClient = useQueryClient()
  const { user } = useAuth()
  
  return useMutation({
    mutationFn: async (bookingData: CreateBookingData) => {
      if (!user) throw new Error('User not authenticated')
      
      const { data, error } = await supabase
        .from('bookings')
        .insert({
          ...bookingData,
          customer_id: user.id,
          status: 'pending',
          payment_status: 'pending',
          confirmation_code: Math.random().toString(36).substring(2, 10).toUpperCase()
        })
        .select()
        .single()

      if (error) {
        throw error
      }

      return data
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['user-bookings'] })
      toast.success('Booking created successfully!')
      return data
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to create booking')
    }
  })
}

export function useUpdateBookingStatus() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: async ({ bookingId, status, notes }: { 
      bookingId: string
      status: string
      notes?: string 
    }) => {
      const updates: any = {
        status,
        updated_at: new Date().toISOString()
      }
      
      if (status === 'confirmed') {
        updates.confirmed_at = new Date().toISOString()
      } else if (status === 'completed') {
        updates.completed_at = new Date().toISOString()
      } else if (status === 'cancelled') {
        updates.cancelled_at = new Date().toISOString()
        if (notes) {
          updates.cancellation_reason = notes
        }
      }
      
      const { data, error } = await supabase
        .from('bookings')
        .update(updates)
        .eq('id', bookingId)
        .select()
        .single()

      if (error) {
        throw error
      }

      return data
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['user-bookings'] })
      queryClient.invalidateQueries({ queryKey: ['provider-bookings'] })
      toast.success('Booking status updated successfully!')
    },
    onError: (error: any) => {
      toast.error(error.message || 'Failed to update booking status')
    }
  })
}