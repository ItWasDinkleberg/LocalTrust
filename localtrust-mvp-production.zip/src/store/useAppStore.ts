import { create } from 'zustand'
import { persist } from 'zustand/middleware'

interface SearchFilters {
  query: string
  categoryId: string | null
  latitude: number | null
  longitude: number | null
  radius: number
  minPrice: number | null
  maxPrice: number | null
  minRating: number | null
  sortBy: 'relevance' | 'price_low' | 'price_high' | 'rating' | 'distance'
}

interface AppState {
  // Search state
  searchFilters: SearchFilters
  setSearchFilters: (filters: Partial<SearchFilters>) => void
  resetSearchFilters: () => void
  
  // Location state
  userLocation: {
    latitude: number | null
    longitude: number | null
    address: string | null
  }
  setUserLocation: (location: { latitude: number, longitude: number, address: string }) => void
  
  // UI state
  isMobileMenuOpen: boolean
  setMobileMenuOpen: (open: boolean) => void
  
  // Search results cache
  searchResults: any[]
  setSearchResults: (results: any[]) => void
  
  // Booking state
  currentBooking: any | null
  setCurrentBooking: (booking: any | null) => void
}

const defaultSearchFilters: SearchFilters = {
  query: '',
  categoryId: null,
  latitude: null,
  longitude: null,
  radius: 25,
  minPrice: null,
  maxPrice: null,
  minRating: null,
  sortBy: 'relevance'
}

export const useAppStore = create<AppState>()(persist(
  (set, get) => ({
    // Search state
    searchFilters: defaultSearchFilters,
    setSearchFilters: (filters) => {
      set((state) => ({
        searchFilters: { ...state.searchFilters, ...filters }
      }))
    },
    resetSearchFilters: () => {
      set({ searchFilters: defaultSearchFilters })
    },
    
    // Location state
    userLocation: {
      latitude: null,
      longitude: null,
      address: null
    },
    setUserLocation: (location) => {
      set({
        userLocation: location,
        searchFilters: {
          ...get().searchFilters,
          latitude: location.latitude,
          longitude: location.longitude
        }
      })
    },
    
    // UI state
    isMobileMenuOpen: false,
    setMobileMenuOpen: (open) => set({ isMobileMenuOpen: open }),
    
    // Search results cache
    searchResults: [],
    setSearchResults: (results) => set({ searchResults: results }),
    
    // Booking state
    currentBooking: null,
    setCurrentBooking: (booking) => set({ currentBooking: booking })
  }),
  {
    name: 'localtrust-app-storage',
    partialize: (state) => ({
      userLocation: state.userLocation,
      searchFilters: state.searchFilters
    })
  }
))