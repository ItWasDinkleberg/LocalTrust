import React from 'react'
import { Card, CardContent } from '../components/ui/Card'

export default function BecomeProviderPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Card>
        <CardContent className="p-8 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Become a Provider</h1>
          <p className="text-sm text-gray-500 mt-4">This page will guide users through the provider registration and verification process.</p>
        </CardContent>
      </Card>
    </div>
  )
}